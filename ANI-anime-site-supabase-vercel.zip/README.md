# ANI — Anime community site

Next.js 14 + Supabase PostgreSQL 기반의 애니 사이트입니다.

## 포함 기능
- 메인: 인기 순위 / 최근 업데이트 / 검색
- 애니 목록 / 상세 / 회차 / 시청 화면
- 회원가입 / 로그인 / 로그아웃
- USER / ADMIN 역할 분리
- 로그인 유저 보관함
- 회차 댓글 작성 / 수정 / 삭제
- 관리자 댓글 삭제
- 관리자 애니 등록 / 수정 / 삭제 / 순위 설정
- API에서도 권한 검사
- `/api/health` 상태 확인
- Supabase PostgreSQL 영속 저장
- Vercel 배포 가능

## 배포 순서
1. Supabase에서 새 프로젝트 생성
2. Supabase SQL Editor에 `supabase-schema.sql` 전체 실행
3. Vercel에서 GitHub 저장소를 Import
4. Vercel Environment Variables에 `.env.example`의 3개 값을 입력
5. Deploy

`SUPABASE_SERVICE_ROLE_KEY`는 절대 브라우저 코드에 넣지 말고 Vercel 서버 환경변수로만 설정합니다.

## 테스트 계정
- 관리자: `admin@ani.local` / `admin1234`
- 일반: `user@ani.local` / `user1234`

운영 전에는 테스트 관리자 비밀번호를 변경하는 것을 권장합니다.
