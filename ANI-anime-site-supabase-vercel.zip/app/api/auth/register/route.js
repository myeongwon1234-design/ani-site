import {NextResponse} from 'next/server';
import {db,write,id,hashPassword,signSession,publicUser} from '../../../../lib/store';
export async function POST(req){
  const {email,password,name}=await req.json();
  const e=String(email||'').trim().toLowerCase(), n=String(name||'').trim();
  if(!/^\S+@\S+\.\S+$/.test(e)) return NextResponse.json({error:'올바른 이메일을 입력하세요.'},{status:400});
  if(String(password||'').length<6) return NextResponse.json({error:'비밀번호는 6자 이상이어야 합니다.'},{status:400});
  if(n.length<2||n.length>20) return NextResponse.json({error:'닉네임은 2~20자로 입력하세요.'},{status:400});
  if((await db()).users.some(u=>u.email===e)) return NextResponse.json({error:'이미 가입된 이메일입니다.'},{status:409});
  const u={id:id('u'),email:e,passwordHash:hashPassword(password),name:n,role:'USER',createdAt:new Date().toISOString()};
  await write(d=>{d.users.push(u);return d});
  const r=NextResponse.json({user:publicUser(u)},{status:201});
  r.cookies.set('ani_session',signSession(u),{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/',maxAge:60*60*24*7});
  return r;
}
