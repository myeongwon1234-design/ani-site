import {NextResponse} from 'next/server';
import {db} from '../../../lib/store';
export async function GET(req){
  const {searchParams}=new URL(req.url); let a=[...(await db()).anime];
  const q=searchParams.get('q');
  if(q)a=a.filter(x=>(x.title+x.subtitle+x.genre.join(' ')).toLowerCase().includes(q.toLowerCase()));
  if(searchParams.get('sort')==='popular')a.sort((x,y)=>y.views-x.views);
  else if(searchParams.get('sort')==='latest')a.sort((x,y)=>new Date(y.createdAt)-new Date(x.createdAt));
  else a.sort((x,y)=>x.rank-y.rank);
  return NextResponse.json({anime:a});
}
