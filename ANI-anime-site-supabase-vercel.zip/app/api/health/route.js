import {NextResponse} from 'next/server';
export async function GET(){return NextResponse.json({ok:true,service:'ANI',time:new Date().toISOString()});}
