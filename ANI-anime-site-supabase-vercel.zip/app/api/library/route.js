import {NextResponse} from 'next/server';import {currentUser,db} from '../../../lib/store';
export async function GET(req){const u=await currentUser(req);if(!u)return NextResponse.json({library:[]});const d=await db();return NextResponse.json({library:d.library.filter(x=>x.userId===u.id)});}
