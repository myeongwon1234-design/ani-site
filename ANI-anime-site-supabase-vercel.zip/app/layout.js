import './globals.css';
export const metadata={title:'ANI — 좋아하는 애니, 한곳에서.',description:'애니메이션 스트리밍 사이트'};
export default function RootLayout({children}){return <html lang="ko"><body>{children}</body></html>}
