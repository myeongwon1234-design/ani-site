-- ANI / Supabase PostgreSQL schema
create extension if not exists pgcrypto;

create table if not exists public.users (
  id text primary key,
  email text not null unique,
  password_hash text not null,
  name text not null,
  role text not null default 'USER' check (role in ('USER','ADMIN')),
  created_at timestamptz not null default now()
);

create table if not exists public.anime (
  id text primary key,
  title text not null,
  subtitle text not null default '',
  year integer not null default 2026,
  genre jsonb not null default '[]'::jsonb,
  score numeric(4,2) not null default 0,
  views bigint not null default 0,
  episodes integer not null default 1,
  rank integer not null default 9999,
  color text not null default 'linear-gradient(135deg,#181329,#7c3aed)',
  created_at timestamptz not null default now()
);

create table if not exists public.comments (
  id text primary key,
  anime_id text not null references public.anime(id) on delete cascade,
  episode integer not null default 1,
  user_id text not null references public.users(id) on delete cascade,
  user_name text not null,
  text text not null,
  date text not null,
  created_at timestamptz not null default now(),
  edited_at timestamptz
);

create table if not exists public.library (
  user_id text not null references public.users(id) on delete cascade,
  anime_id text not null references public.anime(id) on delete cascade,
  primary key (user_id, anime_id)
);

create index if not exists anime_rank_idx on public.anime(rank);
create index if not exists anime_views_idx on public.anime(views desc);
create index if not exists comments_anime_episode_idx on public.comments(anime_id, episode, created_at);

alter table public.users enable row level security;
alter table public.anime enable row level security;
alter table public.comments enable row level security;
alter table public.library enable row level security;

-- The Next.js API uses the Supabase service-role key, so browser clients do not
-- need direct table access. No public RLS policies are created intentionally.

insert into public.users (id,email,password_hash,name,role)
values
('u-admin','admin@ani.local','0b88fefd2f5e43b1ecb4c3b44c1c713ebc8364d7b2284e89b3eabd70036d715ebc9c3ef561862e00a22d4de2d55e498f2c2985ef3f12ed0210de0114f4eeee48','관리자','ADMIN'),
('u-demo','user@ani.local','dd941d53fbaf9c95443e33e65c2394a381102fa51cd621cb5e3adb1a7b3e5af8b41dcec549385d2580d5c90a540786654269a84b61dce07aaa17aebaf13f0890','ANI유저','USER')
on conflict (email) do nothing;

insert into public.anime (id,title,subtitle,year,genre,score,views,episodes,rank,color)
values
('demon-slayer','귀멸의 칼날','합동 강화 훈련편',2026,'["액션","판타지"]',9.8,124000,8,1,'linear-gradient(135deg,#21143a,#b34d68)'),
('jujutsu','주술회전','시부야 사변',2026,'["액션","다크 판타지"]',9.7,108000,23,2,'linear-gradient(135deg,#111827,#6d28d9)'),
('one-piece','원피스','에그헤드',2026,'["모험","액션"]',9.6,99000,1150,3,'linear-gradient(135deg,#172554,#ea580c)'),
('mha','나의 히어로 아카데미아','최종장',2026,'["액션","학원"]',9.5,82000,170,4,'linear-gradient(135deg,#064e3b,#0891b2)'),
('kaiju','괴수 8호','Season 1',2026,'["액션","SF"]',9.3,76000,12,5,'linear-gradient(135deg,#0f172a,#2563eb)'),
('blue-lock','블루 록','Season 2',2026,'["스포츠","드라마"]',9.1,71000,24,6,'linear-gradient(135deg,#172554,#7c3aed)'),
('sakamoto','사카모토 데이즈','Part 1',2026,'["액션","코미디"]',9.0,68000,11,7,'linear-gradient(135deg,#1c1917,#dc2626)'),
('one-punch','원펀맨','Season 3',2026,'["액션","코미디"]',8.9,65000,3,8,'linear-gradient(135deg,#422006,#f59e0b)')
on conflict (id) do nothing;

insert into public.comments (id,anime_id,episode,user_id,user_name,text,date)
values
('c1','demon-slayer',8,'u-demo','ANI유저','이번 화 연출 진짜 좋네요.','2026-09-27'),
('c2','demon-slayer',8,'u-demo','ANI유저','다음 화가 너무 기다려집니다.','2026-09-28')
on conflict (id) do nothing;
